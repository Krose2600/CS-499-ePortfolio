#pragma once
/*
Author: Kayla Rose
Class: CS 300
Assignment: Project 2
Purpose: Advising assistance program

Enhanced for CS 499 Milestone Three:
- Improved file validation
- Added prerequisite validation
- Improved menu input handling
- Organized function declarations in the header file
*/

#include <map>
#include <string>
#include <vector>

using namespace std;

// Structure to hold course information
struct Course {
    string courseNumber;
    string courseTitle;
    vector<string> prerequisites;
};

// Helper functions
string trim(const string& value);
string toUpperCase(string value);
vector<string> splitCsvLine(const string& line);

// Core advising program functions
map<string, Course> loadDataStructure(const string& filename);
bool validatePrerequisites(const map<string, Course>& courses);
void printCourseList(const map<string, Course>& courses);
void printCourseInfo(const map<string, Course>& courses, string courseNum);
int getMenuChoice();

