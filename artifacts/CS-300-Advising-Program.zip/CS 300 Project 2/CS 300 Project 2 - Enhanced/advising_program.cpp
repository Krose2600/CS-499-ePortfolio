#include "advising_program.h"

#include <algorithm>
#include <cctype>
#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>

using namespace std;

// Remove leading and trailing spaces from a string.
// This helps prevent errors when course data contains accidental spacing.
string trim(const string& value) {
    size_t first = value.find_first_not_of(" \t\r\n");
    if (first == string::npos) {
        return "";
    }

    size_t last = value.find_last_not_of(" \t\r\n");
    return value.substr(first, last - first + 1);
}

// Convert course numbers to uppercase so searches are consistent.
// Example: "csci300" and "CSCI300" are treated the same.
string toUpperCase(string value) {
    transform(value.begin(), value.end(), value.begin(),
        [](unsigned char c) { return static_cast<char>(toupper(c)); });
    return value;
}

// Split a comma-separated line from the course file into cleaned tokens.
vector<string> splitCsvLine(const string& line) {
    vector<string> tokens;
    string token;
    stringstream ss(line);

    while (getline(ss, token, ',')) {
        tokens.push_back(trim(token));
    }

    return tokens;
}

// Load course information from a file into a map.
// A map is used because it stores courses by course number and supports efficient lookup.
map<string, Course> loadDataStructure(const string& filename) {
    map<string, Course> courses;
    ifstream file(filename);

    if (!file.is_open()) {
        cout << "Error: Could not open file: " << filename << endl;
        return courses;
    }

    string line;
    int lineNumber = 0;

    while (getline(file, line)) {
        lineNumber++;

        if (trim(line).empty()) {
            continue;
        }

        vector<string> tokens = splitCsvLine(line);

        if (tokens.size() < 2) {
            cout << "Warning: Skipping line " << lineNumber
                << " because it does not contain both a course number and title." << endl;
            continue;
        }

        string courseNumber = toUpperCase(tokens[0]);
        string courseTitle = tokens[1];

        if (courseNumber.empty() || courseTitle.empty()) {
            cout << "Warning: Skipping line " << lineNumber
                << " because the course number or title is blank." << endl;
            continue;
        }

        Course course;
        course.courseNumber = courseNumber;
        course.courseTitle = courseTitle;

        for (size_t i = 2; i < tokens.size(); i++) {
            string prerequisite = toUpperCase(tokens[i]);

            if (!prerequisite.empty()) {
                course.prerequisites.push_back(prerequisite);
            }
        }

        if (courses.find(courseNumber) != courses.end()) {
            cout << "Warning: Duplicate course " << courseNumber
                << " found on line " << lineNumber << ". Existing course was replaced." << endl;
        }

        courses[courseNumber] = course;
    }

    file.close();

    if (!courses.empty()) {
        validatePrerequisites(courses);
    }

    return courses;
}

// Validate that each listed prerequisite also exists as a course in the map.
// This demonstrates using the map data structure for efficient prerequisite lookup.
bool validatePrerequisites(const map<string, Course>& courses) {
    bool allPrerequisitesValid = true;

    for (const auto& pair : courses) {
        const Course& course = pair.second;

        for (const string& prerequisite : course.prerequisites) {
            if (courses.find(prerequisite) == courses.end()) {
                cout << "Warning: " << course.courseNumber
                    << " lists missing prerequisite " << prerequisite << "." << endl;
                allPrerequisitesValid = false;
            }
        }
    }

    return allPrerequisitesValid;
}

// Print all courses in alphanumeric order.
// The map already stores keys in sorted order, but a vector is used here to explicitly
// demonstrate collecting and sorting course keys before display.
void printCourseList(const map<string, Course>& courses) {
    vector<string> courseKeys;

    for (const auto& pair : courses) {
        courseKeys.push_back(pair.first);
    }

    sort(courseKeys.begin(), courseKeys.end());

    cout << "\nCourse List:" << endl;

    for (const string& key : courseKeys) {
        auto course = courses.find(key);
        if (course != courses.end()) {
            cout << course->second.courseNumber << ", "
                << course->second.courseTitle << endl;
        }
    }
}

// Print information for one course and its prerequisites.
void printCourseInfo(const map<string, Course>& courses, string courseNum) {
    courseNum = toUpperCase(trim(courseNum));

    auto course = courses.find(courseNum);

    if (course == courses.end()) {
        cout << "Course not found: " << courseNum << endl;
        return;
    }

    const Course& selectedCourse = course->second;

    cout << selectedCourse.courseNumber << ", "
        << selectedCourse.courseTitle << endl;

    if (selectedCourse.prerequisites.empty()) {
        cout << "Prerequisites: None" << endl;
    }
    else {
        cout << "Prerequisites: ";

        for (size_t i = 0; i < selectedCourse.prerequisites.size(); i++) {
            cout << selectedCourse.prerequisites[i];

            if (i < selectedCourse.prerequisites.size() - 1) {
                cout << ", ";
            }
        }

        cout << endl;
    }
}

// Safely get a menu choice from the user.
// This prevents non-numeric input from breaking the menu loop.
int getMenuChoice() {
    int choice;

    while (true) {
        cout << "Enter your choice: ";

        if (cin >> choice) {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return choice;
        }

        cout << "Invalid input. Please enter a number." << endl;
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}

// Main program
int main() {
    map<string, Course> courses;
    string filename;
    int choice = 0;

    while (choice != 9) {
        cout << "\n==============================" << endl;
        cout << "          Advising Menu       " << endl;
        cout << "==============================" << endl;
        cout << "1. Load Data Structure" << endl;
        cout << "2. Print Course List" << endl;
        cout << "3. Print Course Information" << endl;
        cout << "9. Exit" << endl;
        cout << "==============================" << endl;

        choice = getMenuChoice();

        switch (choice) {
        case 1:
            cout << "Enter the file name: ";
            getline(cin, filename);

            courses = loadDataStructure(filename);

            if (!courses.empty()) {
                cout << "Courses loaded successfully!" << endl;
                cout << courses.size() << " courses loaded." << endl;
            }
            break;

        case 2:
            if (courses.empty()) {
                cout << "Please load the data first using option 1." << endl;
            }
            else {
                printCourseList(courses);
            }
            break;

        case 3:
            if (courses.empty()) {
                cout << "Please load the data first using option 1." << endl;
            }
            else {
                string courseNum;
                cout << "Enter course number: ";
                getline(cin, courseNum);
                printCourseInfo(courses, courseNum);
            }
            break;

        case 9:
            cout << "See you next time!" << endl;
            break;

        default:
            cout << "Invalid option. Please try again." << endl;
            break;
        }
    }

    return 0;
}
