#pragma once
/* 
Author: Kayla Rose 
Class: CS 300 
Date: 10/18/2025
Assignment: Project 2 
Purpose: Advising assistance program 
*/
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

//structure to hold course information 
struct Course {
	string coursenumber;
	string courseTitle;
	vector<string> prerequisites;
};

map<string, Course> loadDataStructure(string filename) {
	map<string, Course> courses;
	ifstream file(filename);

	//Try to open file 
	if (!file.is_open()) {
		cout << "Error: could not open file" << filename << endl;
		return courses;
	}

	string line;
	while (getline(file, line)) {
		stringstream ss(line);
		string courseNum, courseTitle, prereq;
		Course course;

		//Read the course number and title 
		getline(ss, courseNum, ',');
		getline(ss, courseTitle, ',');
		course.coursenumber = courseNum;
		course.courseTitle = courseTitle;

		//Read prereqs
		while (getline(ss, prereq, ',')) {
			course.prerequisites.push_back(prereq);
		}

		courses[courseNum] = course;
	}

	file.close();
	return courses;
}

//Print all courses in alphanumeric oder 
void printCourseList(map<string, Course>& courses) {
	vector<string> courseKeys;

	for (auto& pair : courses) {
		courseKeys.push_back(pair.first);
	}

	sort(courseKeys.begin(), courseKeys.end());

	cout << "\nCourse List: " << endl;
	for (string key : courseKeys) {
		cout << key << ", " << courses[key].courseTitle << endl;
	}
}

//Print info about specific course
void printCourseInfo(map<string, Course>& courses, string courseNum) {
	//check if the course exists in the map
	if (courses.find(courseNum) == courses.end()) {
		cout << "Courses not found: " << courseNum << endl;
		return;
	}
	Course c = courses[courseNum];
	cout << c.coursenumber << ", " << c.courseTitle << endl;

	//Print prereqs if any
	if (c.prerequisites.empty()) {
		cout << "Prerequisites: None" << endl;
	}
	else {
		cout << "Prerequisites: ";
		for (int i = 0; i < c.prerequisites.size(); i++) {
			cout << c.prerequisites[i];
			if (i < c.prerequisites.size() - 1) cout << ", ";
		}
		cout << endl;
	}
}

//main program 
int main() {
	map<string, Course> courses;
	string filename;
	int choice = 0;

	//menu loop
	while (choice != 9) {
		cout << "\n==============================" << endl;
		cout << "          Advising Menu       " << endl;
		cout << "==============================" << endl;
		cout << "1. Load Data Structure" << endl;
		cout << "2. Print Course List" << endl;
		cout << "3. Print Course Information" << endl;
		cout << "9. Exit" << endl;
		cout << "==============================" << endl;
		cout << "Enter your choice: ";
		cin >> choice;

		//Handle each menue option 
		switch (choice) {
			case 1:
				cout << "Enter the file name: ";
				cin >> filename;
				courses = loadDataStructure(filename);
				if (!courses.empty()) {
					cout << "Courses loaded successfully!" << endl;
				}
				break;

			case 2:
				if (courses.empty()) {
					cout << "Please load the data first (Option 1)." << endl;
				}
				else {
					printCourseList(courses);
				}
				break;
			
			case 3:
				if (courses.empty()) {
					cout << "Please load the data first (Option 1)." << endl;
				}
				else {
					string courseNum;
					cout << "Enter course number: ";
					cin >> courseNum;
					printCourseInfo(courses, courseNum);
				}
				break;
			
			case 9:
				cout << "See you next time!" << endl;
				break;

			default:
				cout << "Invalid option, please try again: " << endl;

		}
	}
	return 0;
}

