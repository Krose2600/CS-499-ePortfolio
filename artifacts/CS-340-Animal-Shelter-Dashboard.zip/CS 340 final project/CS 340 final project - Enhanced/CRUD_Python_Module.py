import os
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, OperationFailure, PyMongoError


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, user=None, password=None,
                 host=None, port=None,
                 db=None, col=None):
        """
        Initialize Mongo client and set collection reference.
        """

        self.user = user or os.getenv("AAC_USERNAME", "aacuser")
        self.password = password or os.getenv("AAC_PASSWORD", "pas123")
        self.host = host or os.getenv("AAC_HOST", "localhost")
        self.port = int(port or os.getenv("AAC_PORT", 27017))
        self.db_name = db or os.getenv("AAC_DATABASE", "aac")
        self.collection_name = col or os.getenv("AAC_COLLECTION", "animals")

        self.client = None
        self.database = None
        self.collection = None

        try:
            uri = (
                f"mongodb://{self.user}:{self.password}"
                f"@{self.host}:{self.port}/{self.db_name}?authSource=admin"
            )

            self.client = MongoClient(uri, serverSelectionTimeoutMS=5000)

            # Confirms that MongoDB is reachable and that the login works.
            self.client.admin.command("ping")

            self.database = self.client[self.db_name]
            self.collection = self.database[self.collection_name]

        except ConnectionFailure as e:
            print(f"Connection error: Could not connect to MongoDB. {e}")
        except OperationFailure as e:
            print(f"Authentication error: MongoDB login failed. {e}")
        except PyMongoError as e:
            print(f"Database setup error: {e}")

    def _collection_available(self):
        """
        Checks that the MongoDB collection is available before a CRUD operation runs.
        """
        if self.collection is None:
            print("Database operation failed: collection is not available.")
            return False
        return True

    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        """
        Inserts a document into the animals collection.
        :param data: dict of key/value pairs
        :return: True if successful insert, else False
        """
        if not self._collection_available():
            return False

        if data is None or not isinstance(data, dict) or len(data) == 0:
            print("Create error: data must be a non-empty dictionary.")
            return False

        try:
            result = self.collection.insert_one(data)
            return bool(result.acknowledged and result.inserted_id)
        except PyMongoError as e:
            print(f"Insert error: {e}")
            return False

    # Create method to implement the R in CRUD.
    def read(self, query=None):
        """
        Queries documents from the animals collection.
        IMPORTANT: uses find() not find_one()
        :param query: dict lookup pairs
        :return: list of matching documents, else empty list
        """
        if not self._collection_available():
            return []

        if query is None:
            query = {}

        if not isinstance(query, dict):
            print("Read error: query must be a dictionary.")
            return []

        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except PyMongoError as e:
            print(f"Read error: {e}")
            return []

    # Create method to implement the U in CRUD.
    def update(self, query, new_values):
        """
        Updates documents that match the query.
        :return: number of modified documents
        """
        if not self._collection_available():
            return 0

        if not query or not isinstance(query, dict):
            print("Update error: query must be a non-empty dictionary.")
            return 0

        if not new_values or not isinstance(new_values, dict):
            print("Update error: new_values must be a non-empty dictionary.")
            return 0

        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except PyMongoError as e:
            print(f"Update error: {e}")
            return 0

    # Create method to implement D in CRUD.
    def delete(self, query):
        """
        Deletes documents that match the query.
        :return: number of deleted documents
        """
        if not self._collection_available():
            return 0

        if not query or not isinstance(query, dict):
            print("Delete error: query must be a non-empty dictionary.")
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as e:
            print(f"Delete error: {e}")
            return 0