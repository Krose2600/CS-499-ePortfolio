from pymongo import MongoClient 
from pymongo.errors import PyMongoError
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, user='aacuser', password='pas123',
                 host='localhost', port=27017,
                 db='aac', col='animals'):
        """
        Initialize Mongo client and set collection reference.
        """
        try:
            uri = f"mongodb://{user}:{password}@{host}:{port}/{db}?authSource=admin"
            self.client = MongoClient(uri)
            self.database = self.client[db]
            self.collection = self.database[col]
        except PyMongoError as e:
            print(f"Connection error: {e}")
            self.client = None
            self.database = None
            self.collection = None

    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        """
        Inserts a document into the animals collection.
        :param data: dict of key/value pairs
        :return: True if successful insert, else False
        """
        if data is None or not isinstance(data, dict) or len(data) == 0:
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as e:
            print(f"Insert error: {e}")
            return False

    # Create method to implement the R in CRUD.
    def read(self, query):
        """
        Queries documents from the animals collection.
        IMPORTANT: uses find() not find_one()
        :param query: dict lookup pairs
        :return: list of matching documents, else empty list
        """
        if query is None or not isinstance(query, dict):
            return []

        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except PyMongoError as e:
            print(f"Read error: {e}")
            return []
    #Create method to implement the U in CRUD 
    def update(self, query, new_values):
        
        if not isinstance(query, dict) or not isinstance(new_values, dict):
            return 0
        
        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except PyMongoError as e:
            print(f"Update error: {e}")
            return 0
        
    #Create method to implement D in CRUD 
    def delete(self, query):
        
        if not isinstance(query, dict):
            return 0 
        
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as e:
            print(f"Delete error: {e}")
            return 0